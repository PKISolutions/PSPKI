﻿function Test-WebServerSSL {
<#
.ExternalHelp PSPKI.Help.xml
#>
[CmdletBinding()]
	param(
		[Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)]
		[string]$URL,
		[Parameter(Position = 1)]
		[ValidateRange(1,65535)]
		[int]$Port = 443,
		[Parameter(Position = 2)]
		[Net.WebProxy]$Proxy,
		[Parameter(Position = 3)]
		[int]$Timeout = 15000,
		[switch]$UseUserContext
	)
	$ConnectString = "https://$url`:$port"
	$WebRequest = [Net.WebRequest]::Create($ConnectString)
	$WebRequest.Proxy = $Proxy
	$WebRequest.Credentials = $null
	$WebRequest.Timeout = $Timeout
	$WebRequest.AllowAutoRedirect = $true
	$Response = New-Object PKI.Web.WebSSL -ArgumentList $WebRequest
	$Response.UserContext = $UseUserContext
	$Response.SendRequest()
	$Response
}